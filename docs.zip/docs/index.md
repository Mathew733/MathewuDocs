# MathewuBot <small>``V1.0.0``</small> <!-- {docsify-ignore} -->
W pełni konfigurowalny, wielofunkcyjny i modułowy bot Discord.

?>Strona w budowie

<h2>Komendy</h2>

!>Komend __Moderacyjnych__ może użyć **każdy** kto ma permisje do usuwania wiadomości!              
Dlatego ważna jest zmiana permisji komend w ``Ustawienia serwera->integracje->Mathewu``
- **<h3>Administracyjne</h3>**
  - ``/nick_bot <nick>``
  - ``/wiad <wiadomość>``
- **<h3>Moderacyjne</h3>**
  - ``/UserInfo <user>``
  - ``/warn``
  - ``/mute``
  - ``/unmute``
  - ``/kick``
  - ``/ban``
  - ``/scamban``
  - ``/unban``
  - ``/nick`` 
  - ``/bulk <ilość>``
  - ``/nadajrole <user> <ranga>``
  - ``/usunrole  <user> <ranga>``
  - ``/ilerola <rola>``
  - ``/czasowa <user> <ranga> <dni>`` <small>do zrobienia</small>
- Message menu command
  - ``/przypnij <rola>``
  - ``/edytuj <rola>``


- **<h3>Publiczne</h3>**
  - ``/kot`` ``/pies`` ``/zwierze`` ``/random <typ>``
  - ``/przypomnij``
  - ``/AvatarURL <user>``
- Message menu command
  - ``/zgłoś wiadomość``
- User menu command
  - ``/zgłoś użytkownika``

## StartUp
``/ustawienia-serwera`` ``/ustawienia-sugestii`` ``/ustawienia-przywitania`` ``/startup``

## Eventy
  - Sugestia
  - Reakcje [propozycja tłumaczeń] [Dzień dobry] [Miłego dnia]
  - Responder [Dobranoc]

## TempVoice
``/upoważnij`` ``/temp-menu`` ``/temp-voice``

## Profil
``/profil`` ``/profil-ustawienia``

## Ticket
``/ticket`` <small>do zrobienia</small>